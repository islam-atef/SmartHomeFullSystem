﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities.SqlEntities
{
    public class BaseEntity<T>
    {
        [Required]
        public required T Id { get; set; }

        public DateTime CreatedAt { get; protected set; } = DateTime.UtcNow;

        public string? CreatedBy { get; protected set; }

        public DateTime? ModifiedAt { get; protected set; }

        public string? ModifiedBy { get; protected set; }

        public bool IsDeleted { get; protected set; }

        public DateTime? DeletedAt { get; protected set; }
    }
}
